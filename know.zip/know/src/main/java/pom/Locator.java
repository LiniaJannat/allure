package pom;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.Select;

import base.DriverSetup;

public class Locator extends DriverSetup  {
	
	
	By open = By.xpath ("//header/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[4]/a[1]");
	By login = By.xpath("//input[@data-qa='login-email']");
	By pass = By.xpath("//input[@placeholder='Password']");
	By btn = By.xpath("//button[normalize-space()='Login']");
	
	//product page
	By view = By.xpath("//div[4]//div[1]//div[2]//ul[1]//li[1]//a[1]");
	By addto = By.xpath("//body/section[1]/div[1]/div[1]/div[2]/div[2]/div[2]/div[1]/span[1]/button[1]");
	By shop = By.xpath("//button[normalize-space()='Continue Shopping']");
	By cartview = By.xpath("//body[1]/header[1]/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[3]/a[1]");
	By process = By.xpath("//a[contains(text(),'Proceed To Checkout')]");
	By place = By.xpath("(//a[normalize-space()='Place Order'])[1]");
	By card = By.xpath("//body/section[@id='cart_items']/div[1]/div[3]/div[1]/div[2]/form[1]/div[1]/div[1]/input[1]");
	By cnum = By.xpath("//body/section[@id='cart_items']/div[1]/div[3]/div[1]/div[2]/form[1]/div[2]/div[1]/input[1]");
	By cardname = By.xpath("//input[@name='name_on_card']");
	By cvc = By.xpath("//body/section[@id='cart_items']/div[1]/div[3]/div[1]/div[2]/form[1]/div[3]/div[1]/input[1]");
	By month = By.xpath("//input[@placeholder='MM']");
	By yr = By.xpath("//input[@placeholder='YYYY']");
	By sub = By.xpath("//button[@id='submit']");
	
	
	
	public void clickcardname ()
	{
		driver.findElement(cardname).sendKeys("lin");
	}
	public void clickcnum ()
	{
		driver.findElement(cnum).sendKeys("898574855");
	}
	
	
	public void clickcvc() {
		
		driver.findElement(cvc).sendKeys("ex. 333");
	}
	
	public void clickm () {
		driver.findElement(month).sendKeys("MAY");
	}
	
	public void clickyr () {
		driver.findElement(yr).sendKeys("2030");
	}
	public void clicksub () {
		driver.findElement(sub).click();
	}
	public void clickshop () {
		driver.findElement(shop).click();
	}
	
	public void clickplace () {
		driver.findElement(place).click();
	}
	
	
	public void clickprocess ()
	{
		driver.findElement(process).click();
	}
	
	public void clickcartview () {
		driver.findElement(cartview).click();
	}
	
	
	
	
	
	public void clickopen ()
	{
		driver.findElement(open).click();
	}
	
	public void clicklog ()
	{
		driver.findElement(login).sendKeys("..@ta.com");
	}
	
	public void clickpass ()
	{
		driver.findElement(pass).sendKeys("1234");
	}
	
	public void clickbtn ()
	{
		driver.findElement(btn).click();
	}
	
	public void clickview () {
		driver.findElement(view).click();
	}
	
	public void clickadd () {
		driver.findElement(addto).click();
	}
	
}
