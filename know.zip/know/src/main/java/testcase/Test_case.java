package testcase;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import pom.Locator;

public class Test_case extends Locator {
	
	String baseUrl = "https://automationexercise.com/";
	@Test
	public void learn () throws InterruptedException {
		
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();
		//ChromeOptions opt = new ChromeOptions ();
		//opt.setExperimentalOption("https://automationexercise.com/",Arrays.asList("disable-popup-blocking" ));
		//WebDriver driver = new ChromeDriver (opt);
		//driver.get("https://automationexercise.com/");
		
		Test_case Locator = new Test_case ();
		
		Locator.clickopen();
		Thread.sleep (2000);
		
		Locator.clicklog ();
		Locator.clickpass();
		Locator.clickbtn();
		Thread.sleep (1000);
	
		Actions a = new Actions(driver);
		//scroll down a page
		a.sendKeys(Keys.PAGE_DOWN).build().perform();
		Thread.sleep (2000);
		
		Locator.clickview();
		Thread.sleep (2000);
	       Locator.clickadd();
	   	Thread.sleep (7000);
	   	
	   	Locator.clickshop();
		
		Locator.clickcartview();
		Thread.sleep (2000);
		Locator.clickprocess();
		a.sendKeys(Keys.PAGE_DOWN).build().perform();
		Locator.clickplace();
		Thread.sleep (2000);
		
		
		Locator.clickcardname();
		Locator.clickcnum();
		Thread.sleep (2000);
		Locator.clickcvc();
		Thread.sleep (2000);
		Locator.clickm();
		Thread.sleep (2000);
		Locator.clickyr();
		Locator.clicksub();
	
		Thread.sleep (2000);
     
 
       // Locator.clickdis();
    
        
        
       
		
                
		
		
		
	}
	
	
	

}
